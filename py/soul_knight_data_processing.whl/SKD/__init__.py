# 这是一个元气骑士加密数据处理库，灵感来源于https://github.com/HTCheater/SKDEditor/
# This is an encrypted data processing library for the Prime Knight, inspired by https://github.com/HTCheater/SKDEditor/
# 使用soul_knight.core.Convert()进行操作
# 仓库地址https://github.com/Suto-Commune/soul_knight/
import SKD.core
import SKD.get_official_data
